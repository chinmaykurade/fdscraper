# -*- coding: utf-8 -*-

from fdscraper.preprocess import get_similar_sectors as gss
from fdscraper.scrape import download 
from .utils import get_top_companies as gtc