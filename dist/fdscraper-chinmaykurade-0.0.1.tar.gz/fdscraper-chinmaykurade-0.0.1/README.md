# Indian Stocks- Fundamentals Data Downloader

A web scrapper to download the fundamentals as well as price data from [Screener.in](https://www.screener.in)