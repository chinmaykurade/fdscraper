# -*- coding: utf-8 -*-

from selenium.common.exceptions import NoSuchElementException
from selenium import webdriver
from .utils import get_all_tables